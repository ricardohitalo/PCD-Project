package br.com.padroes.padroes;

public class BlocoNormal extends Bloco{

}
