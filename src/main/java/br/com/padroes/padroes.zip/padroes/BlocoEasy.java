package br.com.padroes.padroes;

public class BlocoEasy extends Bloco{

}
