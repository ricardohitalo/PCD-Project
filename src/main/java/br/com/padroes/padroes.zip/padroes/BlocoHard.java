package br.com.padroes.padroes;

public class BlocoHard extends Bloco{
   
}
